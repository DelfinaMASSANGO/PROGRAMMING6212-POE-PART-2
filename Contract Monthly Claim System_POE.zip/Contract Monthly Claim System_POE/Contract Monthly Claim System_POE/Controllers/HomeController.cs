using Microsoft.AspNetCore.Mvc;

namespace Contract_Monthly_Claim_System_POE.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
