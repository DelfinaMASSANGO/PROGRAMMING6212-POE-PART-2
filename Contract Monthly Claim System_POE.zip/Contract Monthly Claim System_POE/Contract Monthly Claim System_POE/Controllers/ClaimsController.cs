﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Contract_Monthly_Claim_System_POE.Models;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Contract_Monthly_Claim_System_POE.Controllers
{
    public class ClaimsController : Controller
    {
        // Static list of lecturers and claims (if needed in the future)
        private static List<Lecturer> lecturers = new List<Lecturer>
        {
            new Lecturer { LecturerID = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", HourlyRate = 50 }
        };

        private static List<Claim> claims = new List<Claim>();

        // GET: Show claim submission form
        public IActionResult SubmitClaim()
        {
            // You no longer need ViewBag.Lecturers because we are accepting manual input now
            return View();
        }

        // POST: Handle claim submission, including file upload and manual lecturer entry
        [HttpPost]
        public IActionResult SubmitClaim(string firstName, string lastName, string email, int hoursWorked, decimal hourlyRate, string notes, IFormFile supportingDoc)
        {
            // Create a new lecturer object from the provided form data
            var lecturer = new Lecturer
            {
                LecturerID = lecturers.Count + 1, // Simulate auto-increment for the lecturer ID
                FirstName = firstName,
                LastName = lastName,
                Email = email,
                HourlyRate = hourlyRate
            };

            // Optionally add the lecturer to the static list if you want to keep them in memory
            lecturers.Add(lecturer);

            // Handle the file upload
            string filePath = null;
            if (supportingDoc != null)
            {
                var uploads = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);

                filePath = Path.Combine(uploads, supportingDoc.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    supportingDoc.CopyTo(stream);
                }
            }

            // Create a new claim object with the manually entered lecturer and form data
            var claim = new Claim
            {
                ClaimID = claims.Count + 1,
                LecturerID = lecturer.LecturerID,  // Assign the lecturer ID
                Date = DateTime.Now,
                HoursWorked = hoursWorked,
                TotalAmount = hourlyRate * hoursWorked,
                Status = "Pending",
                Notes = notes,
                SupportingDocumentPath = filePath,  // Save document path to the claim
                Lecturer = lecturer  // Attach the manually entered lecturer
            };

            // Add the new claim to the claims list
            claims.Add(claim);

            return RedirectToAction("ClaimSubmitted");
        }

        // GET: Show confirmation page after claim submission
        public IActionResult ClaimSubmitted()
        {
            return View();
        }

        // GET: List all claims
        public IActionResult ListClaims()
        {
            return View(claims);
        }

        // POST: Handle claim verification (approve/reject claims)
        [HttpPost]
        public IActionResult VerifyClaim(int claimID, string action)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimID == claimID);
            if (claim == null) return NotFound();

            if (action == "Approve")
                claim.Status = "Approved";
            else if (action == "Reject")
                claim.Status = "Rejected";

            return RedirectToAction("VerifyClaims");
        }

        // GET: View claims to verify (approve/reject)
        public IActionResult VerifyClaims()
        {
            return View(claims);  // Send all claims to view
        }
    }
}
